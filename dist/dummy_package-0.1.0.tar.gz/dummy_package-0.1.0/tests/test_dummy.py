from dummy_package import dummy_function

def test_dummy_function():
    assert dummy_function() == "Hello, World!"