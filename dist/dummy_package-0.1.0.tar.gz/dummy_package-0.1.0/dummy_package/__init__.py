def dummy_function():
    return "Hello, World!"